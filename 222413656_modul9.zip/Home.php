<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Home - BPS Provinsi Sulawesi Tengah</title>
    <link rel="stylesheet" href="myCSS.css">
    <style>
      
    </style>
  </head>
  <body>
    <header>
    <div class="header-left">
      <img src="logo.png" alt="Logo Web">
      <div class="judulweb">BPS PROVINSI SULAWESI TENGAH</div>
    </div>

    <nav>
      <a class="active" href="Home.php">Home</a>
      <a href="page09A.php">Daftar Publikasi</a>
      <a href="page09C.php">Tambah Publikasi</a>
      <a href="galeri.php">Galeri Kegiatan</a>
      <a href="#">Logout</a>
    </nav>
  </header>

    <div class="hero">
      <h2>Selamat Datang di Portal BPS<br>Provinsi Sulawesi Tengah</h2>
      <p>
        Badan Pusat Statistik (BPS) Provinsi Sulawesi Tengah menyediakan data
        statistik yang akurat, terpercaya, dan terkini untuk mendukung
        pembangunan daerah dan pengambilan keputusan berbasis data.
      </p>
    </div>

    <div class="about-strip">
      <div class="about-strip-text">
        <h3>Tentang BPS Provinsi Sulawesi Tengah</h3>
        <p>
          BPS adalah lembaga pemerintah non-kementerian yang bertugas
          menyelenggarakan kegiatan statistik sesuai peraturan perundang-undangan.
          Data kami menjadi acuan perencanaan dan evaluasi pembangunan di Sulawesi Tengah.
        </p>
        <img src="logo-footer.png" alt="logo berAKHLAK">
      </div>
      <a href="https://sulteng.bps.go.id" target="_blank">Kunjungi Website Resmi</a>
    </div>

    <address>
      Created by Moh. Iryawan F.
      <a href="mailto:222413656@stis.ac.id">(222413656@stis.ac.id)</a>
    </address>

  </body>
</html>